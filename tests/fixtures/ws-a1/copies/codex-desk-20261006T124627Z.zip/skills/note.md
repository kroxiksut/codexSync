an invented skill
